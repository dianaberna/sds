<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<!-- META -->
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<link type="text/css" rel="stylesheet" href="css/style.css" />
        <link rel="icon" type="image/png" href="../images/favicon.ico" />
	<title>Pannello di controllo videosorveglianza antifurto</title>
    <!-- FINE META -->
    <!-- SCRIPT JAVASCRIPT -->
    <script src="js/alert.js"></script>
</head>
<body>
	<!-- INIZIO BARRA FISSA IN ALTO -->
	<div id="topbar">
		<!-- INIZIO LOGO -->
		<img src="images/logo_scuola.png" id="logo1" alt="logo_scuola" />
        <img src="images/logo_arduino.png" id="logo2" alt="logo_arduino" />
        <img src="images/logo_raspi.png" id="logo3" alt="logo_raspi" />
		<!-- FINE LOGO -->
		<!-- INIZIO NAVIGAZIONE -->
		<div id="navigation"> 
		  <table cellpadding="5" cellspacing="10" id="tab" >
          <tr>
			<td><a href="index.php">HOME</a></td>
			<td><a href="progetto.php">PROGETTO</a></td>
			<td><a href="download.php">DOWNLOAD</a></td>
            <?php
			    require_once("pred.php");
			    echo "<td  onclick=\"popup()\" value=\"Show alert box\"><a href=\"http://".$ip_raspberry."/area_privata/login.php\">PANNELLO DI CONTROLLO</a></td>";
			?>
			<td><a href="about.php"  class="current">ABOUT ME</a></td>
		  </tr>
          </table>
		</div>
		<!-- FINE NAVIGAZIONE -->
	</div>
	<!-- FINE BARRA FISSA IN ALTO -->
<div id="log" >
            <?php		
				session_start();
				require_once("pred.php");
				if((!isset($_SESSION['utente']))||($_SESSION['utente']!="ok")){
					echo "<p class='text_log'>
							<img class='icon_log' src='images/button-cross.png'>
							Non sei loggato. Per effettuare il login <a href='http://".$ip_raspberry."/area_privata/login.php'>clicca qui</a>.
						  </p>
						  <p>
							<b>!!! NOTA !!!</b>: per l'accesso e l'utilizzo del pannello di controllo verrai reindirizzato all'ip del webserver locale. 
						  </p>";
				}else{
					echo "<p class='text_log'>
							<img class='icon_log' src='images/button-check.png'>
							Ciao ".$_SESSION['user']." sei loggato. Per effettuare il logout <a href='http://".$ip_raspberry."/area_privata/logout.php'>clicca qui</a>. </p> "; 
				}
			?>
</div>
    <!-- INIZIO CONTAINER --> 
	<table id="container">
	<tr>
    	<td style="padding-left:30px;padding-bottom:30px;min-width:400px;" >
       <h2> ABOUT ME</h2>
        <p> Sono Diana Bernabei e frequento il quinto sez. A della specializzazione Informatica Abacus
	         dell' <b>Istituto tecnico industriale statale "G. & M. Montani"</b> di Fermo.</p>         
		<p> Lo sviluppo di "<b>SDS - SafeDomoticShop</b>" e' stato effettuato come Area di progetto d'esame per l'anno 2012/2013.</p>
		<p> Un sentito ringraziamento va a tutti coloro che durante questi tre anni, mi hanno permesso di esprimere al meglio le mie passioni tecniche, di approfondirle senza limiti, attraverso dei concetti dell'informatica e dell'elettronica specifici a volte non insegnati in questo corso.
Si ringrazia quindi tutto l'apparato scolastico, dalla Preside Margherita Bonanni e il Vicepreside Luigi Sacchi,all'amministrazione, che mi hanno permesso di reperire tutte le componenti elettroniche.
Ma soprattutto ai professori per le tante consulenze date ma anche per le conoscenze che mi hanno tramandato, di seguito: Maura Rogante, Tiziana Magnante, Gino Tombolini, Giuseppe Capitani, Danila Angelici, Fabrizio Postacchini, Mauro Ruffini, Leonardo Paci, Meri Biancucci, Remo Mangiaterra.</p>

<p>Infine un <b>grande ringraziamento</b> va anche a tutti i miei compagni di classe, che mi hanno sopportato e supportato, in questi lunghi cinque anni.</p>

  
    	<img src="images/gmail.png" height="30px" width="30px" /> Per inviarimi un e-mail <a href="mailto:bernabei.d@gmail.com"> clicca qui</a>! 
    	</td>
    </tr>
	</table>
    <div id="footer">
    <img src="images/chrome.png" height="20px" width="20px" /> Sito ottimizzato per Google Chrome 
    </div>
	<!-- FINE CONTAINER -->
</body>
</html>
