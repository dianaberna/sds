function popup(){
		alert("Il pannello di controllo è funzionante solo se il modellino è collegato!");
	}