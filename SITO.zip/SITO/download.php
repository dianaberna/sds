<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<!-- META -->
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<link type="text/css" rel="stylesheet" href="css/style.css" />
    <link rel="icon" type="image/png" href="../images/favicon.ico" />
	<title>Pannello di controllo videosorveglianza antifurto</title>
    <!-- FINE META -->
    <!-- SCRIPT JAVASCRIPT -->
    <script src="js/alert.js"></script>
</head>
<body>
	<!-- INIZIO BARRA FISSA IN ALTO -->
	<div id="topbar">
		<!-- INIZIO LOGO -->
		<img src="images/logo_scuola.png" id="logo1" alt="logo_scuola" />
        <img src="images/logo_arduino.png" id="logo2" alt="logo_arduino" />
        <img src="images/logo_raspi.png" id="logo3" alt="logo_raspi" />
		<!-- FINE LOGO -->
		<!-- INIZIO NAVIGAZIONE -->
		<div id="navigation"> 
		  <table cellpadding="5" cellspacing="10" id="tab" >
          <tr>
			<td><a href="index.php">HOME</a></td>
			<td><a href="progetto.php">PROGETTO</a></td>
			<td><a href="download.php" class="current">DOWNLOAD</a></td>
            <?php
			    
			    require_once("pred.php");
			    echo "<td onclick=\"popup()\" value=\"Show alert box\"><a  href=\"http://".$ip_raspberry."/area_privata/login.php\">PANNELLO DI CONTROLLO</a></td>";
			?>
			<td><a href="about.php">ABOUT ME</a></td>
		  </tr>
          </table>
		</div>
		<!-- FINE NAVIGAZIONE -->
	</div>
	<!-- FINE BARRA FISSA IN ALTO -->
    <div id="log" >
            <?php		
				session_start();
				require_once("pred.php");
				if((!isset($_SESSION['utente']))||($_SESSION['utente']!="ok")){
					echo "<p class='text_log'>
							<img class='icon_log' src='images/button-cross.png'>
							Non sei loggato. Per effettuare il login <a href='http://".$ip_raspberry."/area_privata/login.php'>clicca qui</a>.
						  </p>
						  <p>
							<b>!!! NOTA !!!</b>: per l'accesso e l'utilizzo del pannello di controllo verrai reindirizzato all'ip del webserver locale. 
						  </p>";
				}else{
					echo "<p class='text_log'>
							<img class='icon_log' src='images/button-check.png'>
							Ciao ".$_SESSION['user'].". Per effettuare il logout <a href='http://".$ip_raspberry."/area_privata/logout.php'>clicca qui</a>. </p> "; 
				}
			?>
    </div>
    <!-- INIZIO CONTAINER --> 
	<table id="container">
	<tr>
	    <td style="padding-left:30px;padding-bottom:30px;min-width:400px;" >
       	        
       	        <table>
       	        <tr>
       	        	<td style="width:20px;"></td>
       	        	<td style="width:350px;"><h2> DOWNLOAD</h2></td>
       	        	<td style="width:300px;"><h2> SITI UTILI</h2></td>
       	        <tr>
       	            <td>
	                <a href="https://googledrive.com/host/0B7LAXgTGJ4B3dVFOU3JqcHY5ZDQ/RELAZIONE_PROGETTO.pdf">
	                <img src="images/drive.png" height="20px" width="20px" />  
	                </a>
	            	</td>
	            	<td >
	                <a href="https://googledrive.com/host/0B7LAXgTGJ4B3dVFOU3JqcHY5ZDQ/RELAZIONE_PROGETTO.pdf">
	                Documentazione tecnica
	                </a>
	            	</td>
                    <td><a href="http://www.arduino.cc/">http://www.arduino.cc/</a></td>
	            </tr>
                <tr>
       	            <td>
	                <a href="https://googledrive.com/host/0B7LAXgTGJ4B3dVFOU3JqcHY5ZDQ/schema_sds_bb.png">
	                <img src="images/drive.png" height="20px" width="20px" />  
	                </a>
	            	</td>
	            <td >
	                <a href="https://googledrive.com/host/0B7LAXgTGJ4B3dVFOU3JqcHY5ZDQ/schema_sds_bb.png">
	                Schema elettrico
	                </a>
	            </td>
                <td><a href="http://www.raspberrypi.org/">http://www.raspberrypi.org/</a></td>
	        </tr>
            <tr>
            	<td></td>
                <td>Per il codice di Arduino basta inviarmi<a href="mailto:bernabei.d@gmail.com">  un e-mail</a></td>
                <td><a href="http://rpy-italia.org/">http://rpy-italia.org/</a></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td><a href="http://pibeginners.com/">http://pibeginners.com/</a></td>
            </tr>
            <tr>            	
                <td></td>
                <td></td>
                <td><a href="http://www.w3schools.com/">http://www.w3schools.com/</a></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td><a href="http://it.rs-online.com/web/">http://it.rs-online.com/web/</a></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td><a href="http://www.penguintutor.com/">http://www.penguintutor.com/</a></td>
             </tr>
	         </table>
	    </td>
	</tr>
	</table>
    <!-- FINE CONTAINER -->
    <div id="footer">
        <img src="images/chrome.png" height="20px" width="20px" /> Sito ottimizzato per Google Chrome 
    </div>
</body>
</html>