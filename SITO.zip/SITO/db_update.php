<?php

/************************************************************************
	PROGETTO SDS - by Diana Bernabei
	----------------------------------------
	Carica i valori rilevati da Arduino (IP) sul database 'valori'
	Questo file viene eseguito ogni volta che si chiama l'IP di Arduino 
	(unica azione che permette ad Arduino di collegarsi al database dei valori relativi ai sensori)
************************************************************************/


function connect_database($db_name){
	
	// Definizione variabili di connessione al database
	$host = "localhost";
	$user = "root";
	$pass = "eb6enslc";
	
	// Stabilice una connessione ad un server MySQL
	$db = mysql_connect($host, $user, $pass) or die ("Errore nella connessione al database");
	
	// Imposta il database attualmente attivo sul server associato all'identificativo di connessione specificato
	mysql_select_db($db_name, $db) or die ("MySQL ERROR: ".mysql_error());
	
	// Ritorna la connessione utile per la chiusura 
	return $db; 
	
}
    $s = $_GET["scelta"];
	$db_name = "pannello";
	function accedi(){
         $acces = $_GET["accesso"];
         //require_once("../mysql.php");
		 $db_name = "pannello";
	      $db=connect_database($db_name);
	      $query='UPDATE accesso SET stato="'.$acces.'" WHERE numaccesso="1"'; 
	      mysql_query($query,$db);
          mysql_close($db);
   }
	function luci(){
	    for( $i = 1; $i < 4; $i++ ){
	        $luce[$i] = $_GET[$i];
		}   
	    //require_once("../mysql.php");
		$db_name = "pannello";
	    $db=connect_database($db_name);
	    for( $i = 1; $i < 4; $i++ ){
	    	$query='UPDATE luci SET stato="'.$luce[$i].'" WHERE numluce="'.$i.'"';
	        mysql_query($query,$db); 
	    }
	    mysql_close($db);
	}
	
	 function porta(){
         $door = $_GET["door"];
         //require_once("../mysql.php");
		 $db_name = "pannello";
	      $db=connect_database($db_name);
	      $query='UPDATE porte SET stato="'.$door.'" WHERE numporta="1"'; 
	      mysql_query($query,$db);
          mysql_close($db);
   }
    function pros(){
         $pros = $_GET["pros"];
         //require_once("../mysql.php");
		 $db_name = "pannello";
	      $db=connect_database($db_name);
	      $query='UPDATE pros SET stato="'.$pros.'" WHERE numpir="1"'; 
	      mysql_query($query,$db);
          mysql_close($db);
   }
    $time=0;
    
    switch($s){
	  case 1: // ACCESSO
	  		accedi();
         	echo '<html><head>
			<meta http-equiv="refresh" content="'.$time.'; url=controlli/reload_accedi.php"/>
			</head></html>';
	      	break;
      case 2: // LUCI
	      	luci();
         	echo '<html><head>
			<meta http-equiv="refresh" content="'.$time.'; url=controlli/luci.php"/>
			</head></html>';
	      	break;
	  case 3: // PROSSIMITA'
	      	pros();
         	echo '<html><head>
			<meta http-equiv="refresh" content="'.$time.'; url=controlli/reload_pros.php"/>
			</head></html>';
	      	break;
      case 4: // PORTE
	      	porta();
         	echo '<html><head>
			<meta http-equiv="refresh" content="'.$time.'; url=controlli/reload_porta.php"/>
			</head></html>';
	      	break;
       case 5: // CIRCUITO
   	 }
    
?>

