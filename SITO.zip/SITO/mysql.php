<?php 

/************************************************************************
	PROGETTO SDS - by Diana Bernabei
	----------------------------------------
	Dichiarazione delle specifiche del database + Prima connessione al database 'valori'
************************************************************************/

// Variabile che definisce il nome del database a cui ci si vuole connettere 
$db_name = 'my_safedomoticshop';

function connect_database($db_name){
	
	// Definizione variabili di connessione al database
	$host = "localhost";
	$user = "safedomoticshop";
	$pass = "";
	
	// Stabilice una connessione ad un server MySQL
	$db = mysql_connect($host, $user, $pass) or die ("Errore nella connessione al database");
	
	// Imposta il database attualmente attivo sul server associato all'identificativo di connessione specificato
	mysql_select_db($db_name, $db) or die ("MySQL ERROR: ".mysql_error());
	
	// Ritorna la connessione utile per la chiusura 
	return $db; 
	
}

?>