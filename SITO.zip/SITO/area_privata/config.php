<?php


//file di configurazione variabili

$tua_email = "safedomoticshop@altervista.org";

$sito_internet	=	"safedomoticshop.altervista.org";

$red = "http://safedomoticshop.altervista.org/area_privata/grazie1.php";

?>