<?php

// Includo variabili preimpostate
include('config.php');

session_start();

$nome 		= 	$_POST['nome'];
$cognome 	= 	$_POST['cognome'];
$email 		= 	$_POST['email'];
$username 	= 	$_POST['username'];
$password	= 	MD5($_POST['password']);
$code		=   $_POST['code'];

// Scrivo il codice di verifica nel file .txt

$var1=$code;
if ($var1!=null){
   	$var=fopen("prova.txt","w");
   	fwrite($var,$var1);
   	$var11=file("prova.txt");
   	fclose($var);
   	$i=count($var11);
}

//Invio la mail all'amministratore del sito

$a 			= $tua_email;
$oggetto 	= "Hai ricevuto una mail dal tuo sito internet - $sito_internet";
$messaggio 	= "
<html>
<head>
</head>
<body>
<table width='600' border='0' cellspacing='0' cellpadding='5'>
  <tr>
    <td width='121' align='right' valign='baseline'><strong>Nome:</strong></td>
    <td width='459'>$nome</td>
  </tr>
  
    <tr>
    <td width='121' align='right' valign='baseline'><strong>Cognome:</strong></td>
    <td width='459'>$cognome</td>
  </tr>
   
  <tr>
    <td align='right' valign='baseline'><strong>Email:</strong></td>
    <td>$email</td>
  </tr>
  <tr>
    <td align='right' valign='baseline'><strong>Username:</strong></td>
    <td>$username</td>
  </tr>
  <tr>
    <td align='right' valign='baseline'><strong>Password:</strong></td>
    <td>$password</td>
  </tr>
</table>
</body>
</html>
";

$da 		 = $tua_email;
$headers	 = 'MIME-Version: 1.0' . "\n";
$headers	.= 'Content-type: text/html; charset=iso-8859-1' . "\n"; 
$headers 	.= "From: $da";

//	Invio mail 
mail($a,$oggetto,$messaggio,$headers); 

//	Fine mail inviata all' amministratore del sito 

// Inserisco l'utente con livello di utenza 0

$con = mysqli_connect("localhost", "root", "","my_safedomoticshop");

if (mysqli_connect_errno()) {
	echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$sql="INSERT INTO `reg`(`email`,`cognome`,`nome`,`username`,`password`,`livello`) VALUE ('$email' , '$cognome', '$nome', '$username', '$password', 0); ";	
if (!mysqli_query($con,$sql))
  {
  die('Error: ' . mysqli_error($con));
  }
mysqli_close($con);

// Inizio email di conferma all'utente

$aClient		 		= $email;
$messaggioClient		= "
<html>
<head>
</head>
<body>
    <p>
		<b>Grazie,</b> &nbsp; $nome 
	</p>
	<p>
		per esserti iscritto a $sito_internet.
	</p>
    <p>
		Per confermare la registrazione clicca sul seguente link:
  	</p>
	<p>
		<a href=\"safedomoticshop.altervista.org/area_privata/conferma.php?email=".$email."&codesend=$code\">Conferma iscrizione</a>
	</p>
</body>
</html>
";
$daClient 	 	 = $tua_email;
$oggettoClient	 = "Conferma iscrizione $sito_internet ";
$headersClient	 = 'MIME-Version: 1.0' . "\r\n";
$headersClient	.= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headersClient 	.= "From: $da";

// mail inviata al cliente

mail($aClient,$oggettoClient,$messaggioClient,$headersClient); 

// Fine email di conferma

// Resetto errori

session_destroy();

//Reindirzzo alla pagina specificata in config.php

header("Location: $red"); 
exit;

?>