
<?php  
session_start();
if((!isset($_SESSION['utente']))||($_SESSION['utente']!="ok")){
    echo "Occorre loggarsi";
	echo '<html><head><meta http-equiv="refresh" content="1; url=login.php" />';
	 echo '</head></html> ';
}else{
     //echo "Benvenuto ".$_SESSION['user']; 
echo '
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="refresh" content="1; url=amministrazione.php" />
<style>
#spinner {
	position: absolute;
	top: 282px;
	left: 265px;
	margin: -100px 0 0 -100px;
	height: 200px;
	width: 200px;
	text-indent: 250px;
	white-space: nowrap;
	overflow: hidden;
	-webkit-mask-image: url(spinner.png);
	background-color: #000;
	-webkit-animation-name: spinnerRotate;
	-webkit-animation-duration: 2s;
	-webkit-animation-iteration-count: infinite;
	-webkit-animation-timing-function: linear;
}
@-webkit-keyframes spinnerRotate {
	from {
		-webkit-transform:rotate(0deg);
	}
	to {
		-webkit-transform:rotate(360deg);
	}
}
</style>
</head>

<body>
<p id="spinner">Please wait while we do what we do best.</p>
</body>
</html>';
}
?>
