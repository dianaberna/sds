<?php $time=6; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<!-- META -->
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<link type="text/css" rel="stylesheet" href="../css/style.css" />
    <link rel="icon" type="image/png" href="../images/favicon.ico" />
	<title>Pannello di controllo videosorveglianza antifurto - login</title>
    <style>
	body{
		height:600px;
	}
	</style>
    <!-- FINE META -->
	<?php 
	    echo'<meta http-equiv="refresh" content="'.$time.';url=http://safedomoticshop.altervista.org/index.php " />'; 
	?>
</head>
<body>
	<!-- INIZIO BARRA FISSA IN ALTO -->
	<div id="topbar">
		<!-- INIZIO LOGO -->
		<img src="../images/logo_scuola.png" id="logo1" alt="logo_scuola" />
        <img src="../images/logo_arduino.png" id="logo2" alt="logo_arduino" />
        <img src="../images/logo_raspi.png" id="logo3" alt="logo_raspi" />
		<!-- FINE LOGO -->
		<!-- INIZIO NAVIGAZIONE -->
		<div id="navigation"> 
		  <table cellpadding="5" cellspacing="10" id="tab" >
          <tr>
			<td><a href="../index.php">HOME</a></td>
			<td><a href="../progetto.php">PROGETTO</a></td>
			<td><a href="../download.php">DOWNLOAD</a></td>
	        <?php
			    require_once("../pred.php");
			    echo "<td><a class=\"current\" href=\"http://".$ip_raspberry."/area_privata/login.php\">PANNELLO DI CONTROLLO</a></td>";
			?>
			<td><a href="../about.php">ABOUT ME</a></td>
		  </tr>
          </table>
		</div>
		<!-- FINE NAVIGAZIONE -->
	</div>
	<!-- FINE BARRA FISSA IN ALTO -->
<div id="log" >
            <?php		
				session_start();
				
				if((!isset($_SESSION['utente']))||($_SESSION['utente']!="ok")){
					echo "<p class='text_log'>
							<img class='icon_log' src='../images/button-cross.png'>
							Non sei loggato. Per effettuare il login <a href='login.php'>clicca qui</a>.
						  </p>";
				}else{
				
					echo "<p class='text_log'>
							<img class='icon_log' src='../images/button-check.png'>
							Ciao ".$_SESSION['user']." sei loggato. Per effettuare il logout <a href='logout.php'>clicca qui</a>. </p> "; 
							header("location: amministrazione.php");
				}
			?>
            </div>
    <!-- INIZIO CONTAINER --> 
	<table class="container">
	<!-- INIZIO BARRA FISSA LATERALE -->
      <tr>
		<td style="padding:40px;"> 
			<p><h2>GRAZIE per aver effettuato la registrazione!</h2></p>
			<p>Controlla la tua casella di posta elettronica per confermare l'iscrizione</p>
	
		</td>
      </tr>
	</table>
	<!-- FINE CONTAINER -->
</body>
</html>