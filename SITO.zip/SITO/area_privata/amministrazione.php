<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<!-- META -->
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<link type="text/css" rel="stylesheet" href="../css/style.css" />
    <link rel="icon" type="image/png" href="../images/favicon.ico" />
	<title>Pannello di controllo videosorveglianza antifurto</title>
    <!-- FINE META -->
<?php 
if(isset($_POST["submit"])){
	$var1="<? \$ip_arduino=\"".$_POST['arduino']."\";";
	$var2=" \$ip_raspberry=\"".$_POST['raspberry']."\";?>";
	if ($var1!=null && $var2!=null){
   		$var=@fopen("../pred.php","w");
   		@fwrite($var,$var1."\n".$var2."\n");
   		$var11=file("../pred.php");
   		@fclose($var);
   		$i=count($var11);
	}
	header("location: login.php");
}       
?>
</head>
<body>
	<!-- INIZIO BARRA FISSA IN ALTO -->
	<div id="topbar">
		<!-- INIZIO LOGO -->
		<img src="../images/logo_scuola.png" id="logo1" alt="logo_scuola" />
        <img src="../images/logo_arduino.png" id="logo2" alt="logo_arduino" />
        <img src="../images/logo_raspi.png" id="logo3" alt="logo_raspi" />
		<!-- FINE LOGO -->
		<!-- INIZIO NAVIGAZIONE -->
		<div id="navigation"> 
		  <table cellpadding="5" cellspacing="10" id="tab" >
          <tr>
			<td><a href="../index.php" class="current">HOME</a></td>
			<td><a href="../progetto.php">PROGETTO</a></td>
			<td><a href="../download.php">DOWNLOAD</a></td>
            <?php
			    require_once("../pred.php");
			    echo "<td><a href=\"http://".$ip_raspberry."/area_privata/login.php\">PANNELLO DI CONTROLLO</a></td>";
			?>
			<td><a href="../about.php">ABOUT ME</a></td>
		  </tr>
          </table>
		</div>
		<!-- FINE NAVIGAZIONE -->
	</div>
	<!-- FINE BARRA FISSA IN ALTO -->
<div id="log" >
            <?php		
				session_start();
				require_once("../pred.php");
				if((!isset($_SESSION['utente']))||($_SESSION['utente']!="ok")){
					echo "<p class='text_log'>
							<img class='icon_log' src='../images/button-cross.png'>
							Non sei loggato. Per effettuare il login <a href='http://".$ip_raspberry."/area_privata/login.php'>clicca qui</a>.
						  </p>
						  <p>
							<b>!!! NOTA !!!</b>: per l'accesso e l'utilizzo del pannello di controllo verrai reindirizzato all'ip del webserver locale. 
						  </p>";
				}else{
					echo "<p class='text_log'>
							<img class='icon_log' src='../images/button-check.png'>
							Ciao ".$_SESSION['user']." sei loggato. Per effettuare il logout <a href='logout.php'>clicca qui</a>. </p> "; 
				}
			?>
</div>
    <!-- INIZIO CONTAINER --> 
	<table id="container">
	<!-- INIZIO BARRA FISSA LATERALE -->
    <tr>
		<td id="content" >
		<script>
			function controlla() {
 				if (document.formip.arduino.value == "" || document.formip.raspberry.value == "" ) {
  					alert("Riempire tutti i campi!");
  					return false;
 				}
 				else {
  					document.formip.submit();
 				}
			}
			</script>
			Inserisci i nuovi IP:
		<form action="" method="post" onSubmit="controlla()" name="formip">
		<table>
		<tr>
  			<td>
    		<table>
    		<tr>
      			<td><h3>IP Arduino </td><td><input type="text" name="arduino" /></h3></td>
    		</tr>
    		<tr>
      			<td><h3>IP Raspberry</td><td><input type="text" name="raspberry" /></h3><br></td>
			</tr>
    		</table>
  			</td>
		</tr>
		</table>
		<input type="submit" name="submit" id="loginButton"/>
        <br />
		</form>	
		</td>
		<!-- FINE CONTENT -->
    </tr>
	</table>
    <div id="footer">
    <img src="../images/chrome.png" height="20px" width="20px" /> Sito ottimizzato per Google Chrome 
    </div>
	<!-- FINE CONTAINER -->
</body>
</html>