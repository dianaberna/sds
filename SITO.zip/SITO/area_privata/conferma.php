<?php
	session_start(); 
?>

<!doctype html>
<html>
<head>
</head>
<body>

<?php
$email=$_GET['email'];
$codesend=$_GET['codesend'];

	
	//a questo punto controllo che l'utente sia stato salvato in sessione
	//se si lo stampo
	if (isset($_SESSION['utente'])) {
			echo "<div  class='login_css'>utente ".$_SESSION['utente']. " gi&agrave; loggato!</div>";
	} 
	else {

	$filename = 'prova.txt';
   	$file = fopen($filename, "r");
   	$contents = fread($file, filesize($filename));	
	if( $contents == $codesend){
	
	
		//passo la query al database al quale  mi sono connesso.
		
		//Inizio email di conferma all'utente
	
$con = mysqli_connect("localhost", "root", "","my_safedomoticshop");

if (mysqli_connect_errno()) {
	echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$sql="UPDATE `reg` SET `livello`=1 WHERE `email`= '$email' ; ";	

if (!mysqli_query($con,$sql))
  {
  die('Error: ' . mysqli_error($con));
  }
mysqli_close($con);

	
		$_SESSION["utente"]=$_POST["nome"];
		$_SESSION["username"]=$_POST["username"];
				
		//echo "Registrazione avvenuta con successo, <a href='index.php'>torna alla pagina iniziale</a>";
		//------------------------
		
	}else{
		echo "ERRORE";
	}
   	fclose($file);	
	}
	
header("Location: grazie2.php"); //Reindirzzo alla pagina specificata in config.php
?>

</body>
</html>