<?php
require_once("../mysql.php");
session_start();
if((!isset($_SESSION['utente']))||($_SESSION['utente']!="ok")){
    $user=strip_tags($_POST['user']);
	$_SESSION['user']=$user;
    $pwd=MD5($_POST['pwd']);
    $db_name="my_safedomoticshop";
    $db=mysql_connect($db_host,$db_user,$db_password)or die("Errore nella connessione al db mysql.");
    mysql_select_db($db_name,$db)or die("Errore nella selezione del database mysql.");
    $query='SELECT username, password, livello
			FROM reg 
			WHERE reg.username="'.$user.'" AND reg.password="'.$pwd.'" AND reg.livello=1; ';
    $ris_query=mysql_query($query,$db);
    $righe=mysql_num_rows($ris_query);
    if($righe==0){
        ?>
        <html><head><META HTTP-EQUIV=Refresh CONTENT="0; URL=login.php">
        </head></html>
        <?php
    }else{
        $riga=mysql_fetch_array($ris_query);
        $_SESSION['utente']="ok";
        $_SESSION['utente_id']=$riga['id'];
    }
    mysql_close($db);
}
if((isset($_SESSION['utente']))&&($_SESSION['utente']=="ok")){
    ?>
    <html><head><META HTTP-EQUIV=Refresh CONTENT="0; URL=loggato.php">
    </head></html>
    <?php
}
    