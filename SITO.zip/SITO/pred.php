<? $ip_arduino="10.1.2.34";
 $ip_raspberry="10.1.2.33";?>
