<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" >
<head>
	<!-- META -->
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<link type="text/css" rel="stylesheet" href="../css/style.css" />
	<title>SDS - ACCEDI</title>
    <!-- FINE META -->
</head>
<?php    
   //connessione Mysql
   require_once("../mysql.php");   

   $db0 = connect_database("pannello");  //restituisce la variabile di connessione
   $query = "SELECT * FROM accesso";
   $ris_query = mysql_query($query);
   $righe = mysql_num_rows($ris_query);
if($righe != NULL) {             
      while($riga = mysql_fetch_array($ris_query)){
         $valore = $riga["stato"];
         if($valore  == 1){        
            echo "&nbsp;&nbsp;&nbsp;&nbsp;<br> <img src='../images/button-power_green.png'/><br> Accesso effettuato  ";			
	     }else if ($valore  == 0){
            echo "&nbsp;&nbsp;&nbsp;&nbsp;<br> <img src='../images/button-power_red.png'/><br> Accesso NON effetuato";
		}
      }
      mysql_close($db0);   //chiusura database     
}
?>          
</body>
</html>