<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<!-- META -->
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<link type="text/css" rel="stylesheet" href="../css/style.css" />
	<title>SDS - LUCI</title>
    <!-- FINE META -->
<?php 
require_once("../pred.php");
if(isset($_GET["submit"])){
	$stato1=$_GET["led1"];
	$stato2=$_GET["led2"];
	$stato3=$_GET["led3"];
	
	$invio= "http://".$ip_arduino."/scelta=2&1=".$stato1."&2=".$stato2."&3=".$stato3;
	echo "<meta http-equiv=\"refresh\" content=\"0 ; url=".$invio." \" />";
}       
?>
</head>
<body>
<script>
function controlla() {
 if (document.formluci.led1.value == "" || document.formluci.led2.value == "" || document.formluci.led3.value == "") {
  alert("Riempire tutti i campi!");
  return false;
 }
 else {
  document.formluci.submit();
 }
}
</script>
<h2>LUCI</h2>
<form action="" method="get" onSubmit="controlla()" name="formluci">
<table>
<tr>
  <td>
    <table>
    <tr>
      <td><h3>Principale </td><td><input type="text" name="led1" /></h3></td>
    </tr>
    <tr>
      <td><h3>Tavolo <td> <input type="text" name="led2" /></h3><br></td>
    </tr>
    <tr>
       <td><h3>Davanti SX </td><td><input type="text" name="led3" /> </h3></td>
    </tr>
    </table>
  </td>
  <td>
  <img src="../images/mappa.png" width="350px" height="300px">
  </td>
</tr>
</table>
<input type="submit" name="submit" />
</form>
</body>
</html>