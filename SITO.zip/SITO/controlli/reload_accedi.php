<?php $time=3; ?>

<!DOCTYPE html>
<html>
  <head>
    <?php 
		require_once("../pred.php");
	    echo'<meta http-equiv="refresh" content="'.$time.';url=http://'.$ip_arduino.'/?scelta=1 " />'; 
	?>
  </head>
  <body>
      <?php require_once "accedi.php"; ?>     
  </body>
</html>