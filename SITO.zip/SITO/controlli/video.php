<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<!-- META -->
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<link type="text/css" rel="stylesheet" href="../css/style.css" />
	<title>SDS - VIDEO</title>
    <!-- FINE META -->
</head>
<body>  
      <br/>
      <div>
     <?php 
	 	require_once("../pred.php"); 
        echo '<iframe  src="http://'.$ip_raspberry.':8081/" width="350px" height="240px" frameborder="0"></iframe>';
     ?>
     </div> 
  </body>
</html>        
</body>
</html>