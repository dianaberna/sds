<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<!-- META -->
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<link type="text/css" rel="stylesheet" href="../css/style.css" />
	<title>SDS - PROS</title>
    <!-- FINE META -->
</head>
<body>
<?php    
   //connessione Mysql
   require_once("../mysql.php");   

   $db0 = connect_database('pannello');  //restituisce la variabile di connessione
   $query = "SELECT * FROM pros";
   $ris_query = mysql_query($query);
   $righe = mysql_num_rows($ris_query);
if($righe != NULL) {             
      while($riga = mysql_fetch_array($ris_query)){
         $valore = $riga['stato'];
         if($valore  == 0){        
            echo "&nbsp;&nbsp;&nbsp;&nbsp;<br> <img src='../images/shield-green.png'/> <br> no intruso ";	}
         else{
            echo "&nbsp;&nbsp;&nbsp;&nbsp;<br> <img src='../images/users-red.png'/> <br> <span style=\"color: red\"> intruso</span>";
		}
      }
      mysql_close($db0);   //chiusura database     
}
?>          
 

</body>
</html>      