<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<!-- META -->
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<link type="text/css" rel="stylesheet" href="../css/style.css" />
	<title>SDS - PORTA</title>
    <!-- FINE META -->
</head>
<body>
<?php    
   //connessione Mysql
   require_once("../mysql.php");   

   $db0 = connect_database("pannello");  //restituisce la variabile di connessione
   $query = "SELECT * FROM porte";
   $ris_query = mysql_query($query);
   $righe = mysql_num_rows($ris_query);
if($righe != NULL) {             
      while($riga = mysql_fetch_array($ris_query)){
         $valore = $riga['stato'];
         if($valore  == 1){        
            echo "&nbsp;&nbsp;&nbsp;&nbsp;<br> <img src='../images/lock-green.png'/> <br> &nbsp;chiuso";	}
         else{
            echo "&nbsp;&nbsp;&nbsp;&nbsp;<br> <img src='../images/lock-unlock-red.png'/> <br> <span style=\"color: red\"> &nbsp;aperto</span>";
			$query2 = "SELECT * FROM accesso";
			$ris_query2 = mysql_query($query2);
   			$righe2 = mysql_num_rows($ris_query2);
			$riga2 = mysql_fetch_array($ris_query2);
			$valore2 = $riga2['stato'];
			if($valore2 == 0){
				echo "<br> ATTIVO ALLARME - mando sms";
			}
		}
      }
      mysql_close($db0);   //chiusura database     
}
?>          
 

</body>
</html>