<?php $time=10; ?>

<!DOCTYPE html>
<html>
  <head><title></title>
        <?php 
		    require_once("../pred.php");
		    echo'<meta http-equiv="refresh" content="'.$time.';url=http://'.$ip_arduino.'/?scelta=4 " />'; 
		?>
  </head>
  <body>
      <br/>
      <div>
      <?php require_once "porta.php"; ?>
      </div> 
  </body>
</html>