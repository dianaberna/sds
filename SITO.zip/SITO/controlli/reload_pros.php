<?php $time=1; ?>

<!DOCTYPE html>
<html>
  <head><title></title>
    <?php 
	    require_once("../pred.php");
	    echo'<meta http-equiv="refresh" content="'.$time.';url=http://'.$ip_arduino.'/?scelta=3 " />'; 
	?>
  </head>
  <body>
      <br/>
      <div>
      <?php require_once "pros.php"; ?>
      </div> 
  </body>
</html>